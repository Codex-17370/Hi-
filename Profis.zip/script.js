let stage = 0;

function nextPage() {
  stage++;

  const content = document.getElementById('content');

  if(stage === 1) {
    content.innerHTML = `
      <h1>don’t Click me</h1>
      <button onclick="nextPage()">don’t Click me</button>
    `;
  } else if(stage === 2) {
    document.body.style.backgroundColor = "#000000";
    content.innerHTML = `
      <h1 class="blood">DON‘T DON‘T DON‘T</h1>
      <button onclick="nextPage()">don’t Click me</button>
    `;
  } else if(stage === 3) {
    content.innerHTML = `
      <h1>you wanted it - yrros m‘I</h1>
      <p>23-2292, 24 2910-2<br>10-34, 19 30-415, 6<br>10-2 10-3 10-2</p>
    `;
  }
}
